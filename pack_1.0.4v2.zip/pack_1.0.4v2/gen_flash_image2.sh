# Patch Image File
cd /media/sdcard/pack_1.0.4v2/intel_tools/platform-data 
./platform-data-patch.py -i ../../intel_galileo_1.0.4/Flash-missingPDAT_Release-1.0.4.bin -p ../../../platform-data.ini -n ../../../galiprog_flash_write.bin -u 
cd /media/sdcard 
